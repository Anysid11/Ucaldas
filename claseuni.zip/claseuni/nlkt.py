import nltk
# Descargar los datos de NLTK necesarios (solo la primera vez)
nltk.download('punkt')
nltk.download('wordnet')
nltk.download('punkt_tab')